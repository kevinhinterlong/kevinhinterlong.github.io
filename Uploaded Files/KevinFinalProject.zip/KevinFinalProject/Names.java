import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
/**
 * Write a description of class Names here.
 * 
 * @author Kevin Hinterlong
 * @version May 11, 2015
 */
public class Names
{
    private ArrayList<NameRecord> names;

    /**
     * Create the arraylist to store all of the name records.
     */
    public Names()
    {
        names = new ArrayList<NameRecord>();
        importData();
    }

    /**
     * Loads all of the name data from names.txt into the program
     * 
     */
    public void importData()
    {
        Scanner importer = null;
        try
        {
            importer = new Scanner(new File("names.txt"));
        }
        catch(FileNotFoundException e) //catch the correct exception
        {
            System.out.println(e);
        }
        String line = null;
        while(importer.hasNextLine())
        {
            line = importer.nextLine();
            names.add(new NameRecord(line));
        }
    }

    /**
     * Returns an arraylist of the ranking for the record with the given name
     *
     * @param  name   Name to search for
     * @return     ArrayList of rankings if name is found
     */
    public ArrayList<Integer> getRecord(String name)
    {
        NameRecord record = locate(name);
        if(record != null)
        {
            ArrayList<Integer> ranks = new ArrayList<Integer>(11);
            for(int i = 0; i<11; i++)
            {
                ranks.add(record.getDecade(i));
            }
            return ranks;
        }
        return null;
    }

    /**
     * Return a NameRecord if it is found in the arraylist
     *
     * @param  name   Name to search for
     * @return     NameRecord for given name if found
     */
    public NameRecord locate(String name)
    {
        for(NameRecord record: names)
        {
            if((record.getName()).equalsIgnoreCase(name))
            {
                return record;
            }
        }
        return null;
    }

    /**
     * Returns an arraylist of names whose ranking is strictly increasing.
     *
     * @return     ArrayList of names
     */
    public ArrayList<String> increasingPopularity()
    {
        ArrayList<String> increasing = new ArrayList<String>();
        for(NameRecord record: names)
        {
            if(record.morePopular()) increasing.add(record.getName());
        }
        return increasing;
    }

    /**
     * Returns an arraylist of names whose ranking is striclty decreasing
     *
     * @return     ArrayList of names
     */
    public ArrayList<String> decreasingPopularity()
    {
        ArrayList<String> decreasing = new ArrayList<String>();
        for(NameRecord record: names)
        {
            if(record.lessPopular()) decreasing.add(record.getName());
        }
        return decreasing;
    }

    /**
     * Returns an ArrayList of names who are ranked for every year.
     *
     * @return     ArrayList of names who are ranked every year
     */
    public ArrayList<String> everyDecade()
    {
        ArrayList<String> all = new ArrayList<String>();
        for(NameRecord record: names)
        {
            if(record.everyDecade()) all.add(record.getName());
        }
        return all;
    }

    /**
     * Returns an ArrayList of names who are ranked for only one year.
     *
     * @return     ArrayList of names who are ranked for only one decade
     */
    public ArrayList<String> oneDecade()
    {
        ArrayList<String> one = new ArrayList<String>();
        for(NameRecord record: names)
        {
            if(record.oneDecade()) one.add(record.getName());
        }
        return one;
    }
}
