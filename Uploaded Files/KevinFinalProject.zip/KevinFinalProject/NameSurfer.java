import java.util.Scanner;
import java.util.ArrayList;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.File;
import java.io.IOException;
/**
 * Driver class for the entire name analysis program. 
 * Allows the user to choose from several ways to 
 * analyze the data including a graph. 
 * 
 * @author Kevin Hinterlong
 * @version May 11, 2015
 */

public class NameSurfer
{
    /*
     * Some cool graphs to look at are how Michael is 
     * becoming a more popular name than Mike
     * 
     * during the 80s, the name Asthon started to become popular 
     * and it's interesting to note that Ashton Kutcher was born in 1978
     */
    private Scanner scan;
    private Names names;

    /**
     * Constructor for objects of class NameSurfer
     */
    public NameSurfer()
    {
        scan = new Scanner(System.in);
        System.out.println("Find trends in names! You can create graphs, find trends in the data set,\n" +
            "or just look at data for your own name! Want some hints? Try searching for Kevin");
        scan = new Scanner(System.in);
        names = new Names();
    }

    /**
     * Method main
     *
     * @param args Not useful in this context
     */
    public static void main(String[] args)
    {
        NameSurfer ns = new NameSurfer();
        boolean repeat = true;
        boolean autoClear = false;
        ns.menuOptions(); //give help
        
        System.out.println("Would you like to turn on auto-clear terminal? (recommended)");
        String clearTerm = ns.scan.next();
        int clearCount = 0;
        if(clearTerm.equalsIgnoreCase("yes") || clearTerm.equalsIgnoreCase("y") || clearTerm.contains("yes"))
        {
            autoClear = true;
            System.out.println("Auto clear activated\n");
        }
        
        
        while(repeat)
        {
            System.out.print("Type the operation to perform\n>");
            String ops = ns.scan.next();
            if(ops.contains("1") || (ops.toLowerCase()).contains("search")) //see if a name is in the list and how many decades it was ranked
            {
                clearCount++;
                
                System.out.print("What name would you like to search for?\n>");
                ops = ns.scan.next();
                NameRecord record = ns.names.locate(ops);
                if(record == null)
                {
                    System.out.println("That name was not found in the database.");
                    continue;
                }
                System.out.println("There are " + record.decadesRanked() + " decades with data for that name.");
            }
            else if(ops.contains("2") || (ops.toLowerCase()).contains("data")) //show the decade rankings for names which were ranked only one decade
            {
                clearCount += 5;
                
                System.out.print("What name would you like to search for?\n>");
                ops = ns.scan.next();
                ArrayList<Integer> data = ns.names.getRecord(ops);
                if(data == null)
                {
                    System.out.println("That name was not found in the database.");
                    continue;
                }
                int[] year = {1900,1910,1920,1930,1940,1950,1960,1970,1980,1990,2000};
                for(int i = 0; i<11; i++)
                {
                    System.out.println("Ranking for " + year[i] + " is: " + data.get(i) + ".");
                }
            }
            else if(ops.contains("3") || (ops.toLowerCase()).contains("once")) //show names which were ranked only one decade
            {
                clearCount++;
                
                if(ns.names.oneDecade() == null)
                {
                    System.out.println("No names were found in the database.");
                    continue;
                }
                ns.write("oneDecade.txt", "Here are all the names that appear in one decade:", ns.names.oneDecade());
            }
            else if(ops.contains("4") || (ops.toLowerCase()).contains("every")) //show names which were ranked every decade
            {
                clearCount++;
                
                if(ns.names.everyDecade() == null)
                {
                    System.out.println("No names were found in the database.");
                    continue;
                }
                ns.write("everyDecade.txt", "Here are all the names that appear in one decade:", ns.names.everyDecade());
            }
            else if(ops.contains("5") || (ops.toLowerCase()).contains("graph")) //Show a visual representation of the variation of the ranking
            {
                clearCount++;
                
                System.out.print("What name would you like to search for?\n>");
                ops = ns.scan.next();
                if(ns.names.locate(ops) == null)
                {
                    System.out.println("That name was not found in the database.");
                    continue;
                }
                Drawing graph = new Drawing(ops, (ns.names.locate(ops)).getRanks());
            }
            else if(ops.contains("6") || (ops.toLowerCase()).contains("increas") ) //show all names which are strictly increasing
            {
                clearCount++;
                
                ns.write("increasing.txt", "Here are all the names which are increasing in every decade:", ns.names.increasingPopularity());
            }
            else if(ops.contains("7") || (ops.toLowerCase()).contains("decreas") ) //show all names which are strictly decreasing
            {
                clearCount++;
                
                ns.write("decreasing.txt", "Here are all the names which are decreasing in every decade:", ns.names.decreasingPopularity());
            }
            else if(ops.contains("8") || (ops.toLowerCase()).contains("help")) //help
            {
                ns.clear();
            }
            else if(ops.contains("9") || (ops.toLowerCase()).contains("quit") || (ops.toLowerCase()).contains("exit")) //exit the program
            {
                break;
            }
            
            if(autoClear && clearCount>12)
            {
                ns.clear();
            }
        }
        System.out.println("Thank you!");
    }

    /**
     * Print out helpful instructions for the 
     * user so that they can make best use of the program.
     */
    public void menuOptions()
    {
        System.out.println("\nPlease choose one of the following: ");
        System.out.println("1. Search for a name in the database");
        System.out.println("2. Display the record for a particular name");
        System.out.println("3. Display all the names that appear in only one decade");
        System.out.println("4. Display all the names that appear in all the decades");
        System.out.println("5. Display a visual representation of a particular name");
        System.out.println("6. Display all the names whose ranks are striclty increasing");
        System.out.println("7. Display all the names whose ranks are striclty decreasing");
        System.out.println("8. See this help menu");
        System.out.println("9. Quit the program\n");
    }
    
    /**
     * Clear the terminal so that it is easier 
     * to read and interact with
     */
    public void clear()
    {
        Scanner wait = new Scanner(System.in);
        System.out.println(">>Hit enter to clear<<");
        wait.nextLine();
        System.out.print("\f");
        menuOptions();
    }
    
    /**
     * Writes to files for lists which will be too long for the terminal
     */
    public void write(String filename, String operation, ArrayList<String> names)
    {
        try
        {
            BufferedWriter bw = new BufferedWriter(new FileWriter(new File(filename)));
            for(int i = 0; i<names.size(); i++)
            {
                bw.write((i+1) + " " + names.get(i));
                bw.newLine();
            }
            bw.close();
            System.out.println("Success! Data was written to " + filename);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
}
