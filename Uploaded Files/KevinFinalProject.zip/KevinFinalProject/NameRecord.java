/**
 * Stores the name and rankings of a name through the decades 1900 to 2000
 * 
 * @author Kevin Hinterlong
 * @version May 11, 2015
 */
public class NameRecord
{
    private int[] ranking;
    private String name;
    
    /**
     * Input the data from the line
     *
     * @param line Unformatted line of code with name and 11 integers
     */
    public NameRecord(String line)
    {
        String[] unformatted = line.split(" "); //split string by spaces
        name = unformatted[0]; //first spot is the name
        ranking = new int[11]; //make array to hold the ints
        for(int i = 0; i < 11; i++)
        {
            ranking[i] = Integer.parseInt(unformatted[i+1]); //parse the ints and pass them to the real array
        }
    }

    /**
     * Return the name associated with the set of data
     *
     * @return     Name associated with the data
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * Return the integer rankings of the name during each decade from 1900 - 2000 inclusive
     *
     * @return     array of rankings 1900 = 0
     */
    public int[] getRanks()
    {
        return ranking;
    }

    /**
     * Returns true if the associated data shows a decrease in ranking.
     *
     * @return     true if rank is decreasing
     */
    public boolean lessPopular()
    {
        boolean decrease = true;
        for(int i = 0; i<10; i++)
        {
            if((ranking[i] == ranking[i+1]) || (ranking[i+1] < ranking[i] && ranking[i+1] != 0))
            {
                decrease = false;
            }
        }
        return decrease;
    }
    
    /**
     * Returns true if the associated data shows an increase in ranking
     *
     * @return     true if rank is increasing
     */
    public boolean morePopular()
    {
        boolean increase = true;
        for(int i = 0; i<10; i++)
        {
            if((ranking[i] == ranking[i+1]) || (ranking[i+1] > ranking[i] && ranking[i] != 0))
            {
                increase = false;
            }
        }
        return increase;
    }
    
    /**
     * Returns the rank of the name during the given decade. 1900 = 0
     * 
     * @param  year   The index/decade to get the ranking of
     * @return     The rank during that decade
     */
    public int getDecade(int decade)
    {
        return ranking[decade];
    }

    /**
     * Return the decade with the highest ranking
     *
     * @return     Decade with highest ranking
     */
    public String bestDecade()
    {
        int greatest = 1000;
        int decade = 0;
        for(int i = 0; i< 11; i++)
        {
            if(ranking[i] <= greatest && ranking[i] != 0)
            {
                greatest = ranking[i]; //set highest ranking
                decade = i; //store index
            }
        }
        if(decade == 10) //special case for output
        {
            return "2000";
        }
        
        return "19" + decade + "0"; //return decade
    }

    /**
     * Counts how many decades the name has been ranked
     *
     * @return     Number of decades with a rank
     */
    public int decadesRanked()
    {
        int count = 0;
        for(int i:ranking)
        {
            if(i != 0) count++;
        }
        return count;
    }

    /**
     * Checks to see if this name has only been ranked in one decade
     *
     * @return     true if ranked only once
     */
    public boolean oneDecade()
    {
        if(decadesRanked() == 1) return true;
        return false;
    }

    /**
     * Checks to see if this name has been ranked in every decade
     *
     * @return     true if ranked every decade
     */
    public boolean everyDecade()
    {
        if(decadesRanked() == 11) return true;
        return false;
    }
}
