import java.util.ArrayList;
import java.awt.Font;
/**
 * Draws a plot with the data for the given name.
 * 
 * @author Kevin Hinterlong
 * @version May 11, 2015
 */
public class Drawing
{
    private int[] data;
    private String name;
    private SimpleCanvas canvas;

    /**
     * Make a canvas and draw a title on it then draw the data and the plot
     */
    public Drawing(String name, int[] data)
    {
        this.data = data;
        this.name = name.substring(0,1).toUpperCase() + name.substring(1).toLowerCase();
        
        canvas = new SimpleCanvas("Name through the decades", 1000, 700, true);
        canvas.setForegroundColour(java.awt.Color.RED);
        canvas.setFont(new Font("TimesRoman", Font.BOLD, 20));
        canvas.drawString("Here is the name '" + this.name + "' through the decades:", 200, 40);
        canvas.setFont(new Font("TimesRoman", Font.PLAIN, 16));
        
        drawPlot();
        drawData();
    }

    /**
     * Draw the basis of the plot
     * 
     */
    public void drawPlot()
    {
        //draw the top and bottom of graph
        for(int i = 70; i<600; i+= 500)
        {
            canvas.drawLine(8,i,8+11*980/data.length,i);
        }
        
        //draw the vertical lines for each decade
        for(int i = 0; i<12; i++)
        {
            canvas.drawLine(8 + i*980/data.length,70,8 + i*980/data.length,570);
        }
        
        //write the year at the bottom of each bar
        int[] year = {1900, 1910, 1920, 1930, 1940, 1950, 1960, 1970, 1980, 1990, 2000};
        for(int i = 0; i< 11; i++)
        {
            canvas.drawString(year[i] + "", 20 + i*980/data.length, 585);
        }
    }

    /**
     * Draw the data points on the graph to see a visual representation.
     *
     */
    public void drawData()
    {
        //Draw the name at each point
        for(int i = 0; i< data.length; i++)
        {
            canvas.drawString(name + " " + data[i], 10+(980/data.length)*i, 68+ data[i]/2);
        }
        
        //draw lines connecting the points
        for(int i=0; i<10; i++)
        {
            canvas.drawLine(10 + i*980/data.length, 70+data[i]/2, 10 + (i+1)*980/data.length, 70+data[i+1]/2);
        }
    }

}
